package ls223qx_lab1.ferry;

public class Passenger {
	public Passenger() {
		// Empty constructor, since we don't really care about passenger attributes
		// only needs to be an empty object that exists
	}

}
